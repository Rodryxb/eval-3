// Importamos las librerías instaladas
require('dotenv').config();
const express = require('express'); 
const cors = require('cors'); 
const mongoose = require('mongoose'); 
const bcrypt = require('bcrypt'); // Necesario para la contraseña obligatoria[cite: 5]
const dns = require('node:dns/promises');

dns.setServers(['1.1.1.1','8.8.8.8','1.0.0.1']);

// Iniciar la aplicación express
const aplicacion = express();
const puerto = process.env.port || 3000;

// Instanciar las clases necesarias en nuestra aplicación
aplicacion.use(cors());
aplicacion.use(express.json());

// Crear la conexión a DB
mongoose.connect(process.env.URI)
    .then(() => console.log('Conexión Exitosa a MongoDB!'))
    .catch((excepcion) => console.log('No ha sido posible conectarse por el siguiente error: ', excepcion));

// ==========================================
// 1. DEFINICIÓN DE ESQUEMAS Y MODELOS
// ==========================================

// Esquema de Comuna
const comunaSchema = new mongoose.Schema({
    codigo: String,
    nombre: String,
    region: String
});
const Comuna = mongoose.model('Comuna', comunaSchema, 'comunas');

// Esquema de País (Mantenido de tu código original)
const paisSchema = new mongoose.Schema({
    nombre: String,
    iso2: String,
    iso3: String,
    codigoPais: String,
    nacionalidad: String
});
const Pais = mongoose.model('Pais', paisSchema, 'paises');

// ESQUEMA ACTUALIZADO DE USUARIO (Cumpliendo la rúbrica)[cite: 5]
const usuarioSchema = new mongoose.Schema({
    nombre: { type: String, required: true }, // Obligatorio[cite: 5]
    rut: { type: String, required: true }, // Obligatorio[cite: 5]
    correo: { type: String, required: true }, // Obligatorio[cite: 5]
    telefono: { type: String },
    fechaNacimiento: { 
        type: Date, 
        required: true,
        validate: {
            validator: function(v) { return v < new Date(); }, // Fecha válida y anterior a la actual[cite: 5]
            message: 'La fecha de nacimiento debe ser en el pasado.'
        }
    },
    nacionalidad: { type: String, required: true }, // Código ISO-3166 Alpha-2[cite: 5]
    genero: { type: String, enum: ['M', 'F', 'O'] }, // Valores permitidos[cite: 5]
    direccion: { 
        type: {
            comuna: String,
            calle: String,
            numero: String,
            departamento: String
        }, 
        required: true // Objeto obligatorio[cite: 5]
    },
    contrasena: { type: String, required: true }, // Obligatorio[cite: 5]
    fechaRegistro: { type: Date, default: Date.now }, // Asignación automática[cite: 5]
    activo: { type: Boolean, default: true } // Valor predeterminado true[cite: 5]
});
const Usuario = mongoose.model('Usuario', usuarioSchema, 'usuarios');

// NUEVA ENTIDAD: Pedido (Ejemplo de entidad asignada)[cite: 5]
const pedidoSchema = new mongoose.Schema({
    descripcion: { type: String, required: true },
    monto: { type: Number, required: true },
    rutUsuarioAsociado: { type: String, required: true } // Llave foránea para el $lookup
});
const Pedido = mongoose.model('Pedido', pedidoSchema, 'pedidos'); // Crea el Schema, Model y Colección[cite: 5]


// ==========================================
// 2. RUTAS Y MÉTODOS (ENDPOINTS)
// ==========================================

// Método POST para registrar Usuario con Hash bcrypt[cite: 5]
aplicacion.post('/guardarUsuario', async (request, response) => {
    try {
        const { nombre, correo, rut, telefono, contrasena, fechaNacimiento, genero, nacionalidad, direccion } = request.body;

        const saltRounds = 10;
        const contrasenaEncriptada = await bcrypt.hash(contrasena, saltRounds); // Encriptación bcrypt requerida[cite: 5]

        const jsonDireccion = typeof direccion === 'string' ? JSON.parse(direccion) : direccion;

        const nuevoUsuario = new Usuario({ 
            nombre, correo, rut, telefono, 
            contrasena: contrasenaEncriptada, 
            fechaNacimiento, genero, nacionalidad, 
            direccion: jsonDireccion 
        });

        await nuevoUsuario.save();
        response.status(200).json({ mensaje: 'Usuario almacenado correctamente.' });
    } catch (excepcion) {
        response.status(500).json({ mensaje: 'No se han podido almacenar los datos: ', excepcion });
    }
});

// Método POST para la Nueva Entidad (Pedido)[cite: 5]
aplicacion.post('/guardarPedido', async (request, response) => {
    try {
        const { descripcion, monto, rutUsuarioAsociado } = request.body;
        const nuevoPedido = new Pedido({ descripcion, monto, rutUsuarioAsociado });
        
        await nuevoPedido.save();
        response.status(200).json({ mensaje: 'Pedido almacenado correctamente.' });
    } catch (error) {
        response.status(500).json({ mensaje: 'Error al almacenar el pedido: ', error });
    }
});

// Método GET con Agregación $lookup para relacionar Pedidos y Usuarios[cite: 5]
aplicacion.get('/pedidos', async (request, response) => {
    try {
        const pedidosConUsuarios = await Pedido.aggregate([
            {
                $lookup: {
                    from: 'usuarios', // Colección de usuarios[cite: 5]
                    localField: 'rutUsuarioAsociado', // Campo en pedidos
                    foreignField: 'rut', // Campo en usuarios
                    as: 'datosUsuario' // Alias del arreglo resultante[cite: 5]
                }
            },
            {
                $unwind: '$datosUsuario' // Desintegra el arreglo para que sea un objeto plano
            }
        ]);

        if (!pedidosConUsuarios || pedidosConUsuarios.length === 0) {
            return response.status(404).json({ mensaje: 'No se encontraron registros.' });
        }

        response.status(200).json(pedidosConUsuarios);
    } catch (error) {
        response.status(500).json({ mensaje: 'No ha sido posible obtener los datos relacionados: ', error });
    }
});

// GET original de usuarios con país
aplicacion.get('/usuarios', async (request, response) => {
    try {
        const usuarios = await Usuario.aggregate([{ 
            $lookup:{
                from:'paises', 
                localField:'nacionalidad', 
                foreignField:'iso2', 
                as: 'paisOrigen' 
            }
        }]);

        if (!usuarios || usuarios.length === 0) {
            return response.status(404).json({ mensaje: 'No se encontraron usuarios.' });
        }
        response.status(200).json(usuarios);
    } catch (error) {
        response.status(500).json({ mensaje: 'Error al obtener usuarios: ', error })
    }
});

// GET de Paises (Mantenido)
aplicacion.get('/paises', async (req, res) => {
    try {
        const listaPaises = await Pais.find(); // Asegúrate que 'Pais' sea el nombre de tu modelo
        res.json(listaPaises);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al obtener países', error });
    }
});


// GET de Comunas (Mantenido)
aplicacion.get('/comunas', async (request, response) => {
    try {
        const comunas = await Comuna.find().exec();
        response.status(200).json(comunas);
    } catch (error) {
        response.status(500).json({ mensaje: 'Error al obtener comunas: ', error })
    }
});

// Poner el servidor en escucha
aplicacion.listen(puerto, () => console.log(`Corriendo en el puerto ${puerto}`));